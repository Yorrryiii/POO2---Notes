package ej3;

public class AsignaturaNotFoundException extends Exception{
    public AsignaturaNotFoundException(String message) {
        super(message);
    }
}
