package ej3;

public class DobleMatriculaException extends Exception{
    public DobleMatriculaException(String message) {
        super(message);
    }
}
