package ej3;

public class AsignaturaSinAlumnosException extends Exception{
    public AsignaturaSinAlumnosException(String message) {
        super(message);
    }
}
