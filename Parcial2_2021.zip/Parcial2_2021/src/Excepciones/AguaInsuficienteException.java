package Excepciones;

public class AguaInsuficienteException extends Exception{
    public AguaInsuficienteException(String message) {
        super(message);
    }
}
