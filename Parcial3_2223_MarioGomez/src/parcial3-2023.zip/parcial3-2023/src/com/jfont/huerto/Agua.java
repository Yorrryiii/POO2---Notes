package com.jfont.huerto;

public enum Agua {
	alta, media, baja
}
